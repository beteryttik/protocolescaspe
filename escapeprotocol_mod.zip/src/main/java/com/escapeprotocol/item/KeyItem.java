package com.escapeprotocol.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/**
 * A key collected from a room. Different key colors map to different doors.
 */
public class KeyItem extends Item {
    public KeyItem(Settings settings) {
        super(settings);
    }

    public static int getColor(ItemStack stack) {
        return stack.getOrCreateNbt().getInt("Color");
    }
}
