package com.escapeprotocol.item;

import net.minecraft.item.Item;

/** Quietly opens a locked door. One use. Does not trigger noise. */
public class PuttyItem extends Item {
    public PuttyItem(Settings settings) {
        super(settings);
    }
}
