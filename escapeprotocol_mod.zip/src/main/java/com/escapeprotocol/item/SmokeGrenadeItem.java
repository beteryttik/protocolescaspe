package com.escapeprotocol.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * Thrown smoke: blocks line-of-sight, making the maniac lose his chase
 * target while inside the smoke volume.
 */
public class SmokeGrenadeItem extends Item {
    public SmokeGrenadeItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            // TODO: spawn SmokeAreaEntity with 15s lifetime, radius 4 blocks.
            stack.decrement(1);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
