package com.escapeprotocol.item;

import net.minecraft.item.Item;

/** Maniac's trap: immobilizes a survivor who steps on it until freed. */
public class TrapItem extends Item {
    public TrapItem(Settings settings) {
        super(settings);
    }
}
