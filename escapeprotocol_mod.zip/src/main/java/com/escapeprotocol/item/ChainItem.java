package com.escapeprotocol.item;

import net.minecraft.item.Item;

/**
 * Restraining chain: survivors can stun the maniac for ~5 seconds on a
 * successful close-range use. Consumed on use.
 */
public class ChainItem extends Item {
    public ChainItem(Settings settings) {
        super(settings);
    }
    // TODO: use() applies Slowness 6 + attack cooldown lock to the maniac for 100 ticks.
}
