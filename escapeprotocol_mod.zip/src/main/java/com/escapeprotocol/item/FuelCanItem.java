package com.escapeprotocol.item;

import net.minecraft.item.Item;

/** Refuels a generator for 25% when used on it. */
public class FuelCanItem extends Item {
    public FuelCanItem(Settings settings) {
        super(settings);
    }
}
