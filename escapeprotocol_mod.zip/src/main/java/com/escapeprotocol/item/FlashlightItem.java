package com.escapeprotocol.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

/**
 * Survivors' flashlight. Holds charge; the beam can be seen by the maniac
 * from a distance (handled client-side rendering + server noise of light).
 */
public class FlashlightItem extends Item {
    private static final String KEY_CHARGE = "Charge";
    private static final int MAX_CHARGE = 1200; // 60 seconds of continuous use

    public FlashlightItem(Settings settings) {
        super(settings);
    }

    public static int getCharge(ItemStack stack) {
        return stack.getOrCreateNbt().getInt(KEY_CHARGE);
    }

    public static void drain(ItemStack stack, int amount) {
        NbtCompound nbt = stack.getOrCreateNbt();
        int charge = Math.max(0, nbt.getInt(KEY_CHARGE) - amount);
        nbt.putInt(KEY_CHARGE, charge);
    }

    public static void recharge(ItemStack stack, int amount) {
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putInt(KEY_CHARGE, Math.min(MAX_CHARGE, nbt.getInt(KEY_CHARGE) + amount));
    }
}
