package com.escapeprotocol.player;

import com.escapeprotocol.ai.NoiseEvent;
import com.escapeprotocol.ai.NoiseSystem;
import com.escapeprotocol.ai.NoiseType;
import com.escapeprotocol.config.ConfigManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

/**
 * Computes how loud an action is and publishes the noise event.
 * Called from movement/event hooks (mixins or event handlers).
 */
public final class StealthHelper {
    private StealthHelper() {}

    public static void noiseFromMovement(PlayerEntity player, boolean running, boolean sneaking) {
        ConfigManager cfg = ConfigManager.get();
        double radius = sneaking ? cfg.noiseSneakRadius() : running ? cfg.noiseRunRadius() : cfg.noiseWalkRadius();
        if (player.hasStatusEffect(com.escapeprotocol.registry.ModStatusEffects.QUIET_STEPS)) {
            radius *= 0.4;
        }
        NoiseSystem.publish(new NoiseEvent(player.getBlockPos(), radius,
                sneaking ? NoiseType.SNEAK : running ? NoiseType.RUN : NoiseType.WALK));
    }

    public static void noiseFromBlockBreak(PlayerEntity player, BlockPos pos) {
        NoiseSystem.publish(new NoiseEvent(pos, ConfigManager.get().noiseBlockBreakRadius(), NoiseType.BLOCK_BREAK));
    }
}
