package com.escapeprotocol.player;

import com.escapeprotocol.config.ConfigManager;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Per-player match state: role, sanity, noise contributions, loadout.
 * Persisted across respawns within a match via attachments on the player.
 */
public class MatchPlayer {
    private final ServerPlayerEntity player;
    private boolean maniac;
    private double sanity = 100.0;
    private int keysCollected;
    private int generatorsFixed;
    private int score;

    public MatchPlayer(ServerPlayerEntity player) {
        this.player = player;
    }

    public MatchPlayer asManiac() {
        this.maniac = true;
        return this;
    }

    public boolean isManiac() {
        return maniac;
    }

    public ServerPlayerEntity getPlayer() {
        return player;
    }

    public double getSanity() {
        return sanity;
    }

    public void addSanity(double delta) {
        sanity = Math.max(0, Math.min(100, sanity + delta));
    }

    public void tickSanity(long ticksElapsed) {
        if (maniac) return;
        if (ticksElapsed % 20 != 0) return;

        // Darkness drains sanity. Placeholder: use light level at player's feet.
        boolean inDark = player.getWorld().getLightLevel(player.getBlockPos()) < 3;
        if (inDark) {
            addSanity(-ConfigManager.get().sanityDrainPerSecondDark());
        }
        // TODO: seeing the maniac applies an instant drain (handled by maniac AI when it sees a survivor).
    }

    public int getKeysCollected() { return keysCollected; }
    public void addKey() { keysCollected++; score += 10; }
    public int getGeneratorsFixed() { return generatorsFixed; }
    public void addGeneratorFixed() { generatorsFixed++; score += 15; }
    public int getScore() { return score; }
}
