package com.escapeprotocol.world;

import com.escapeprotocol.game.arena.ArenaManager;
import com.escapeprotocol.world.safezone.SafeZoneData;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Builds a match arena:
 * 1. Generates a room graph (entry hall -> corridors -> rooms -> elevator hall).
 * 2. Places NBT templates anchored at door frames.
 * 3. Spreads keys (weighted by BFS distance), generators (>=3 clusters),
 *    save-zones and the elevator.
 */
public final class ArenaGenerator {
    private final ArenaManager.ArenaType type;
    private final Random random = new Random();

    public ArenaGenerator(ArenaManager.ArenaType type) {
        this.type = type;
    }

    public ArenaResult generate(ServerWorld world, BlockPos center) {
        RoomGraph graph = buildGraph();
        placeTemplates(world, center, graph);
        List<BlockPos> keyPositions = spreadKeys(world, center, graph);
        List<BlockPos> generatorPositions = placeGenerators(world, center, graph);
        List<SafeZoneData> safeZones = placeSaveZones(world, center, graph);
        BlockPos elevator = placeElevator(world, center, graph);
        return new ArenaResult(graph, keyPositions, generatorPositions, safeZones, elevator);
    }

    private RoomGraph buildGraph() {
        RoomGraph graph = new RoomGraph();
        int radius = 4;
        RoomGraph.Node entry = graph.add(0, 0, RoomGraph.RoomKind.ENTRY, random);
        RoomGraph.Node hall = graph.add(1, 0, RoomGraph.RoomKind.HALL, random);
        graph.connect(entry.id(), hall.id());

        // Corridors ring.
        RoomGraph.Node prevCorridor = null;
        for (int i = 0; i < radius * 2; i++) {
            RoomGraph.Node corridor = graph.add(2 + i, 0, RoomGraph.RoomKind.CORRIDOR, random);
            graph.connect(i == 0 ? hall.id() : prevCorridor.id(), corridor.id());
            prevCorridor = corridor;
        }

        // Side rooms off corridors.
        for (int x = 2; x < 2 + radius * 2; x++) {
            for (int z = -1; z <= 1; z += 2) {
                if (random.nextFloat() < 0.6f) {
                    RoomGraph.Node room = graph.add(x, z, randomRoomKind(), random);
                    // connect to nearest corridor
                    // TODO: better matching via nearest-neighbor search.
                    graph.connect(graph.bfsFromEntry().get(graph.bfsFromEntry().size() - 1).id(), room.id());
                }
            }
        }

        RoomGraph.Node elevatorHall = graph.add(2 + radius * 2, 0, RoomGraph.RoomKind.ELEVATOR_HALL, random);
        graph.connect(prevCorridor.id(), elevatorHall.id());
        return graph;
    }

    private RoomGraph.RoomKind randomRoomKind() {
        RoomGraph.RoomKind[] kinds = {
                RoomGraph.RoomKind.BEDROOM, RoomGraph.RoomKind.BATH,
                RoomGraph.RoomKind.STORAGE, RoomGraph.RoomKind.SAFE_ZONE,
                RoomGraph.RoomKind.MANIAC_LAIR
        };
        RoomGraph.RoomKind kind = kinds[random.nextInt(kinds.length)];
        return kind;
    }

    private void placeTemplates(ServerWorld world, BlockPos center, RoomGraph graph) {
        for (RoomGraph.Node node : graph.bfsFromEntry()) {
            RoomTemplate template = new RoomTemplate(node.templateId(), 16, 16);
            BlockPos anchor = center.add(node.gridX() * 16, 0, node.gridZ() * 16);
            template.place(world, anchor);
        }
    }

    private List<BlockPos> spreadKeys(ServerWorld world, BlockPos center, RoomGraph graph) {
        List<RoomGraph.Node> byDistance = graph.bfsFromEntry();
        List<BlockPos> keys = new ArrayList<>();
        int total = type.minKeys + 2;
        for (int i = 0; i < total; i++) {
            // Prefer distant rooms: sample from the back half of the BFS order.
            int idx = Math.min(byDistance.size() - 1, byDistance.size() - 1 - random.nextInt(Math.max(1, byDistance.size() / 2)));
            RoomGraph.Node node = byDistance.get(idx);
            BlockPos pos = center.add(node.gridX() * 16 + 8, 64, node.gridZ() * 16 + 8);
            keys.add(pos);
        }
        return keys;
    }

    private List<BlockPos> placeGenerators(ServerWorld world, BlockPos center, RoomGraph graph) {
        List<BlockPos> generators = new ArrayList<>();
        for (int i = 0; i < type.generators; i++) {
            RoomGraph.Node node = graph.bfsFromEntry().get(random.nextInt(Math.max(1, graph.bfsFromEntry().size())));
            generators.add(center.add(node.gridX() * 16 + 8, 64, node.gridZ() * 16 + 8));
        }
        return generators;
    }

    private List<SafeZoneData> placeSaveZones(ServerWorld world, BlockPos center, RoomGraph graph) {
        List<SafeZoneData> zones = new ArrayList<>();
        for (int i = 0; i < type.saveZones; i++) {
            // Save zones sit mid-distance: reachable but not free.
            List<RoomGraph.Node> nodes = graph.bfsFromEntry();
            RoomGraph.Node node = nodes.get(Math.min(nodes.size() - 1, nodes.size() / 2 + i));
            zones.add(new SafeZoneData(center.add(node.gridX() * 16 + 8, 64, node.gridZ() * 16 + 8)));
        }
        return zones;
    }

    private BlockPos placeElevator(ServerWorld world, BlockPos center, RoomGraph graph) {
        return center.add(graph.elevator().gridX() * 16, 64, graph.elevator().gridZ() * 16);
    }

    public record ArenaResult(RoomGraph graph, List<BlockPos> keys, List<BlockPos> generators,
                              List<SafeZoneData> safeZones, BlockPos elevator) {}
}
