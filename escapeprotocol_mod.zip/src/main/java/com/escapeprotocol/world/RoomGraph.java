package com.escapeprotocol.world;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Graph of rooms for a match. Nodes are placed on a coarse grid,
 * edges connect adjacent rooms. Distances are used for loot placement:
 * the farther a room is from spawn, the better the loot.
 */
public final class RoomGraph {
    public record Node(UUID id, int gridX, int gridZ, RoomKind kind, String templateId) {}

    public enum RoomKind { ENTRY, CORRIDOR, BEDROOM, BATH, STORAGE, HALL, ELEVATOR_HALL, SAFE_ZONE, MANIAC_LAIR }

    private final Map<UUID, Node> nodes = new HashMap<>();
    private final Map<UUID, List<UUID>> edges = new HashMap<>();
    private UUID entryId;
    private UUID elevatorId;

    public Node add(int gridX, int gridZ, RoomKind kind, Random random) {
        UUID id = UUID.randomUUID();
        Node node = new Node(id, gridX, gridZ, kind, pickTemplate(kind, random));
        nodes.put(id, node);
        edges.put(id, new ArrayList<>());
        if (kind == RoomKind.ENTRY) entryId = id;
        if (kind == RoomKind.ELEVATOR_HALL) elevatorId = id;
        return node;
    }

    private String pickTemplate(RoomKind kind, Random random) {
        // Templates are NBT structures in resources. Naming convention:
        // escapeprotocol:arena/<theme>/<kind>_<variant>.nbt
        return kind.name().toLowerCase() + "_" + random.nextInt(3);
    }

    public void connect(UUID a, UUID b) {
        edges.get(a).add(b);
        edges.get(b).add(a);
    }

    public Node entry() {
        return nodes.get(entryId);
    }

    public Node elevator() {
        return nodes.get(elevatorId);
    }

    public List<Node> bfsFromEntry() {
        // Simple BFS returning nodes ordered by distance from entry.
        List<Node> ordered = new ArrayList<>();
        var queue = new ArrayList<UUID>();
        var visited = new HashMap<UUID, Integer>();
        if (entryId == null) return ordered;
        queue.add(entryId);
        visited.put(entryId, 0);
        while (!queue.isEmpty()) {
            UUID current = queue.remove(0);
            ordered.add(nodes.get(current));
            for (UUID next : edges.get(current)) {
                if (!visited.containsKey(next)) {
                    visited.put(next, visited.get(current) + 1);
                    queue.add(next);
                }
            }
        }
        return ordered;
    }
}
