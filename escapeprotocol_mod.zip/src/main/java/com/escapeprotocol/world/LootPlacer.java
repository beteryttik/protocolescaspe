package com.escapeprotocol.world;

import com.escapeprotocol.registry.ModItems;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Random;

/**
 * Places loot in chests. Deliberately scarce: fewer bandages and fuel cans
 * than the "comfortable" amount, per the LOLoloshka-style design.
 */
public final class LootPlacer {
    private LootPlacer() {}

    public static void place(ServerWorld world, List<BlockPos> chests, Random random) {
        for (BlockPos pos : chests) {
            int roll = random.nextInt(100);
            ItemStack stack;
            if (roll < 30) stack = new ItemStack(ModItems.BANDAGE);
            else if (roll < 50) stack = new ItemStack(ModItems.FUEL_CAN);
            else if (roll < 70) stack = new ItemStack(ModItems.SMOKE_GRENADE);
            else if (roll < 85) stack = new ItemStack(ModItems.PUTTY);
            else stack = new ItemStack(ModItems.FLARE);
            // TODO: insert into the chest's inventory, not the block position.
        }
    }
}
