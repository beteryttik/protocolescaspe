package com.escapeprotocol.world;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.world.ServerWorld;

/**
 * Wrapper over an NBT structure with a standard 1x2x3 door anchor on
 * every side. Ensures corridors align between templates.
 */
public final class RoomTemplate {
    public static final int DOOR_WIDTH = 1;
    public static final int DOOR_HEIGHT = 2;
    public static final int DOOR_DEPTH = 3;

    private final String templateId;
    private final int sizeX;
    private final int sizeZ;

    public RoomTemplate(String templateId, int sizeX, int sizeZ) {
        this.templateId = templateId;
        this.sizeX = sizeX;
        this.sizeZ = sizeZ;
    }

    /** Places the template into the world at the given anchor. */
    public void place(ServerWorld world, BlockPos anchor) {
        // TODO: use StructureTemplateManager.loadStructureFromResource(templateId)
        // and place with the anchor aligned to the door frames.
    }

    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.putString("template", templateId);
        nbt.putInt("sizeX", sizeX);
        nbt.putInt("sizeZ", sizeZ);
        return nbt;
    }
}
