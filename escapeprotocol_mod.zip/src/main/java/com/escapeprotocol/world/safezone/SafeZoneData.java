package com.escapeprotocol.world.safezone;

import net.minecraft.util.math.BlockPos;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Runtime state of one save-zone: occupants, kick timer, whether the
 * maniac is currently camping the door.
 */
public class SafeZoneData {
    private final BlockPos doorPos;
    private final Set<UUID> occupants = new HashSet<>();
    private long expiresAt;
    private boolean doorBroken;

    public SafeZoneData(BlockPos doorPos) {
        this.doorPos = doorPos;
    }

    public BlockPos getDoorPos() {
        return doorPos;
    }

    public void enter(UUID player, long now, long stayTicks) {
        occupants.add(player);
        expiresAt = now + stayTicks;
    }

    public void exit(UUID player) {
        occupants.remove(player);
    }

    public boolean isOccupied() {
        return !occupants.isEmpty();
    }

    public boolean expired(long now) {
        return isOccupied() && now >= expiresAt;
    }

    public long ticksLeft(long now) {
        return Math.max(0, expiresAt - now);
    }

    public Set<UUID> occupants() {
        return occupants;
    }

    public void clearOccupants() {
        occupants.clear();
    }

    public boolean isDoorBroken() {
        return doorBroken;
    }

    public void markDoorBroken() {
        doorBroken = true;
    }
}
