package com.escapeprotocol.world.safezone;

import com.escapeprotocol.config.ConfigManager;
import com.escapeprotocol.game.GameManager;
import com.escapeprotocol.networking.Payloads;
import com.escapeprotocol.registry.ModSounds;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Per-tick logic for save-zones:
 *  - maniac cannot damage players inside;
 *  - occupancy timer kicks out campers;
 *  - breaking the door is loud (NoiseEvent to everyone).
 */
public final class SafeZoneTracker {
    private final List<SafeZoneData> zones = new ArrayList<>();

    public void add(SafeZoneData zone) {
        zones.add(zone);
    }

    public List<SafeZoneData> getZones() {
        return zones;
    }

    public SafeZoneData zoneAt(BlockPos pos) {
        for (SafeZoneData zone : zones) {
            if (zone.getDoorPos().isWithinDistance(pos, 8)) return zone;
        }
        return null;
    }

    public boolean isProtected(ServerPlayerEntity player) {
        for (SafeZoneData zone : zones) {
            if (zone.getDoorPos().isWithinDistance(player.getBlockPos(), 8)) return true;
        }
        return false;
    }

    public void tick(ServerWorld world, long now) {
        Iterator<SafeZoneData> it = zones.iterator();
        while (it.hasNext()) {
            SafeZoneData zone = it.next();
            if (zone.expired(now)) {
                world.playSound(null, zone.getDoorPos(), ModSounds.SAFE_ZONE_CLICK, SoundCategory.HOSTILE, 1f, 1f);
                zone.getDoorPos().offset(net.minecraft.util.math.Direction.NORTH);
                zone.occupants().forEach(uuid -> {
                    ServerPlayerEntity p = world.getServer().getPlayerManager().getPlayer(uuid);
                    if (p != null) {
                        p.sendMessage(Text.literal("\u00a7cThe safe zone door clicks open."), false);
                        p.networkHandler.sendPacket(Payloads.safeZoneKick((int) zone.ticksLeft(now)));
                    }
                });
                zone.clearOccupants();
            }
        }
    }

    /** Maniac breaks the door — loud for everyone. */
    public void onManiacBreak(SafeZoneData zone, ServerWorld world) {
        zone.markDoorBroken();
        world.playSound(null, zone.getDoorPos(), ModSounds.DOOR_CREAK, SoundCategory.HOSTILE, 2f, 0.5f);
        // Noise event reaching the whole map is the price of entry.
        com.escapeprotocol.ai.NoiseSystem.publish(new com.escapeprotocol.ai.NoiseEvent(
                zone.getDoorPos(), 128.0, com.escapeprotocol.ai.NoiseType.SAFE_ZONE_BREAK));
    }
}
