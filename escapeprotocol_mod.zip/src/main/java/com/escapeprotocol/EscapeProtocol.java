package com.escapeprotocol;

import com.escapeprotocol.config.ConfigManager;
import com.escapeprotocol.game.GameManager;
import com.escapeprotocol.registry.ModBlocks;
import com.escapeprotocol.registry.ModBlockEntities;
import com.escapeprotocol.registry.ModEntities;
import com.escapeprotocol.registry.ModItems;
import com.escapeprotocol.registry.ModSounds;
import com.escapeprotocol.registry.ModStatusEffects;
import com.escapeprotocol.commands.EpCommand;
import com.escapeprotocol.networking.ServerNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Escape Protocol — asymmetric multiplayer horror.
 *
 * 1 maniac vs 1..8 survivors in a procedurally generated safehouse.
 * Survivors: collect keys, fuel generators, call the elevator, escape.
 * Maniac: hunts noise, sets traps, can mimic a survivor until first strike.
 */
public class EscapeProtocol implements ModInitializer {
    public static final String MOD_ID = "escapeprotocol";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[Escape Protocol] Booting...");

        ConfigManager.load();

        ModStatusEffects.register();
        ModSounds.register();
        ModBlocks.register();
        ModBlockEntities.register();
        ModItems.register();
        ModEntities.register();

        ServerNetworking.register();

        ServerTickEvents.END_SERVER_TICK.register(server -> GameManager.get().tick(server));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                EpCommand.register(dispatcher));

        LOGGER.info("[Escape Protocol] Initialized. Stay quiet.");
    }
}
