package com.escapeprotocol.ai;

public enum ManiacState {
    PATROL,      // wandering the map, listening
    INVESTIGATE, // moving to the last heard noise
    CHASE,       // direct pursuit of a visible survivor
    SEARCH,      // lost the target, sweeping nearby rooms
    AMBUSH,      // waiting near a save-zone or generator
    RAGE         // endgame: faster, more aggressive
}
