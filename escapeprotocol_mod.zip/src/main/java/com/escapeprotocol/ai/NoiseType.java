package com.escapeprotocol.ai;

public enum NoiseType {
    RUN, WALK, SNEAK, BLOCK_BREAK, DOOR_KICK, TRAP_SET, GENERATOR_RUNNING,
    SAFE_ZONE_BREAK, FLARE, SMOKE_POP, ELEVATOR_CALL
}
