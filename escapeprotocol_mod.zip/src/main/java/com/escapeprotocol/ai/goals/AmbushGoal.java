package com.escapeprotocol.ai.goals;

import com.escapeprotocol.ai.ManiacBrain;
import com.escapeprotocol.world.safezone.SafeZoneTracker;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.PathAwareEntity;

import java.util.EnumSet;

/**
 * Camps near a save-zone with occupants: the maniac cannot enter while
 * the door holds, but he can wait. Camping costs him time elsewhere.
 */
public class AmbushGoal extends Goal {
    private final PathAwareEntity maniac;
    private final ManiacBrain brain;
    private final SafeZoneTracker zones;

    public AmbushGoal(PathAwareEntity maniac, ManiacBrain brain, SafeZoneTracker zones) {
        this.maniac = maniac;
        this.brain = brain;
        this.zones = zones;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        if (brain.getState() != com.escapeprotocol.ai.ManiacState.AMBUSH) return false;
        return zones.getZones().stream().anyMatch(z -> z.isOccupied() && !z.isDoorBroken());
    }

    @Override
    public void start() {
        // TODO: path to just outside the safe-zone door.
    }

    @Override
    public boolean shouldContinue() {
        return canStart();
    }
}
