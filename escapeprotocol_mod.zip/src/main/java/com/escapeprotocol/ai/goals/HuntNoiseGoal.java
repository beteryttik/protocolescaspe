package com.escapeprotocol.ai.goals;

import com.escapeprotocol.ai.ManiacBrain;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.util.math.BlockPos;

import java.util.EnumSet;

/**
 * Moves the maniac toward the current target of his brain:
 * the last heard noise (INVESTIGATE), a seen survivor (CHASE), or the
 * elevator hall (RAGE).
 */
public class HuntNoiseGoal extends Goal {
    private final PathAwareEntity maniac;
    private final ManiacBrain brain;
    private BlockPos target;

    public HuntNoiseGoal(PathAwareEntity maniac, ManiacBrain brain) {
        this.maniac = maniac;
        this.brain = brain;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        return brain.getState() == com.escapeprotocol.ai.ManiacState.INVESTIGATE
                || brain.getState() == com.escapeprotocol.ai.ManiacState.CHASE;
    }

    @Override
    public void start() {
        // TODO: pull the actual target from the brain, not a stub.
        target = maniac.getBlockPos().add(8, 0, 0);
        maniac.getNavigation().startMovingTo(target.getX(), target.getY(), target.getZ(), 1.1);
    }

    @Override
    public boolean shouldContinue() {
        return canStart() && maniac.getNavigation().isFollowingPath();
    }
}
