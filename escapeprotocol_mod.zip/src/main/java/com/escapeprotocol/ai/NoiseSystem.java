package com.escapeprotocol.ai;

import java.util.ArrayList;
import java.util.List;

/**
 * Server-side pub/sub for noise events. The maniac AI and client HUD
 * both subscribe. Producers: movement, block break, door kick, trap set,
 * generator running, safe-zone break.
 */
public final class NoiseSystem {
    private static final List<Listener> listeners = new ArrayList<>();

    public interface Listener {
        void onNoise(NoiseEvent event);
    }

    public static void subscribe(Listener listener) {
        listeners.add(listener);
    }

    public static void publish(NoiseEvent event) {
        for (Listener l : List.copyOf(listeners)) {
            l.onNoise(event);
        }
    }
}
