package com.escapeprotocol.ai;

import com.escapeprotocol.config.ConfigManager;
import com.escapeprotocol.config.ConfigManager;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.EnumMap;
import java.util.Map;
import java.util.Random;

/**
 * Finite state machine for the maniac bot (solo mode) and a shared
 * "brain" for the player-controlled maniac's assist systems.
 *
 * PATROL -> (noise) -> INVESTIGATE -> (sees survivor) -> CHASE
 *        -> (lost sight) -> SEARCH -> PATROL
 *        -> (near save-zone with occupant) -> AMBUSH
 *        -> (elevator called) -> RAGE
 */
public final class ManiacBrain implements NoiseSystem.Listener {
    private ManiacState state = ManiacState.PATROL;
    private final Map<ManiacState, Long> stateEnterTick = new EnumMap<>(ManiacState.class);
    private BlockPos lastNoise;
    private BlockPos lastSeenTarget;
    private long lastSeenTick;
    private final Random random = new Random();

    private final com.escapeprotocol.entity.ManiacEntity maniac;

    public ManiacBrain(com.escapeprotocol.entity.ManiacEntity maniac) {
        this.maniac = maniac;
        NoiseSystem.subscribe(this);
    }

    @Override
    public void onNoise(NoiseEvent event) {
        ConfigManager cfg = ConfigManager.get();
        double distance = Math.sqrt(maniac.squaredDistanceTo(event.pos().getX(), event.pos().getY(), event.pos().getZ()));
        if (distance <= Math.min(event.radius(), cfg.maniacHearingRange())) {
            lastNoise = event.pos();
            if (state == ManiacState.PATROL || state == ManiacState.SEARCH) {
                transition(ManiacState.INVESTIGATE);
            }
        }
    }

    public void tick(ServerWorld world, long ticks) {
        switch (state) {
            case PATROL -> {
                // Wander to random room anchors. Listening bonus if idle.
                if (random.nextFloat() < 0.05f) {
                    transition(ManiacState.INVESTIGATE); // head toward last known noise or random room
                }
            }
            case INVESTIGATE -> {
                if (lastNoise != null && maniac.getBlockPos().isWithinDistance(lastNoise, 2)) {
                    transition(ManiacState.SEARCH);
                }
            }
            case CHASE -> {
                // Chase is driven by entity goals (HuntNoiseGoal). Handle loss of sight.
                if (ticks - lastSeenTick > 100) {
                    transition(ManiacState.SEARCH);
                }
            }
            case SEARCH -> {
                if (ticks - stateEnterTick.getOrDefault(ManiacState.SEARCH, 0L) > 200) {
                    transition(ManiacState.PATROL);
                }
            }
            case AMBUSH -> {
                // Wait near a safe-zone with occupants. Leaves if zone empties.
                if (random.nextFloat() < 0.01f) {
                    transition(ManiacState.PATROL);
                }
            }
            case RAGE -> {
                // Endgame speed handled by attribute modifier.
            }
        }
    }

    public void onSeesSurvivor(net.minecraft.entity.LivingEntity target, long ticks) {
        lastSeenTarget = target.getBlockPos();
        lastSeenTick = ticks;
        if (state != ManiacState.CHASE && state != ManiacState.RAGE) {
            transition(ManiacState.CHASE);
        }
    }

    public void onElevatorCalled(long ticks) {
        transition(ManiacState.RAGE);
    }

    private void transition(ManiacState next) {
        stateEnterTick.put(state, System.currentTimeMillis());
        state = next;
        // TODO: notify client audio director (tension/chase music switch).
    }

    public ManiacState getState() {
        return state;
    }
}
