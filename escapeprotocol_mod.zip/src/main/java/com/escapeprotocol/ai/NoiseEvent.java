package com.escapeprotocol.ai;

import net.minecraft.util.math.BlockPos;

public record NoiseEvent(BlockPos pos, double radius, NoiseType type) {
}
