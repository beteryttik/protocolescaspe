package com.escapeprotocol.mixin;

import com.escapeprotocol.game.GameManager;
import com.escapeprotocol.world.safezone.SafeZoneTracker;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftServer.class)
public class ServerTickMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void escapeprotocol$tick(CallbackInfo ci) {
        GameManager.get().tick((MinecraftServer) (Object) this);
    }
}
