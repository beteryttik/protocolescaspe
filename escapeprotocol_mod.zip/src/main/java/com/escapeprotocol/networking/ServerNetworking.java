package com.escapeprotocol.networking;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.util.Identifier;

/**
 * C2S handlers. First iteration: only a "ready" ping from the lobby UI.
 */
public final class ServerNetworking {
    public static final Identifier PLAYER_READY = new Identifier("escapeprotocol", "player_ready");

    private ServerNetworking() {}

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(PLAYER_READY, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                // TODO: flip readiness in LobbyManager.
            });
        });
    }
}
