package com.escapeprotocol.networking;

import com.escapeprotocol.game.arena.ArenaManager;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.network.packet.s2c.custom.CustomPayloadS2CPacket;

/**
 * S2C payload constructors. Clients read these to drive the HUD,
 * audio director and shake effects.
 */
public final class Payloads {
    public static final Identifier MATCH_STARTED = new Identifier("escapeprotocol", "match_started");
    public static final Identifier SAFE_ZONE_KICK = new Identifier("escapeprotocol", "safe_zone_kick");
    public static final Identifier MANIAC_PROXIMITY = new Identifier("escapeprotocol", "maniac_proximity");
    public static final Identifier SANITY_UPDATE = new Identifier("escapeprotocol", "sanity_update");
    public static final Identifier CHASE_STATE = new Identifier("escapeprotocol", "chase_state");

    private Payloads() {}

    public static CustomPayloadS2CPacket matchStarted(ArenaManager.ArenaType type) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeEnumConstant(type);
        return new CustomPayloadS2CPacket(MATCH_STARTED, buf);
    }

    public static CustomPayloadS2CPacket safeZoneKick(int seconds) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(seconds);
        return new CustomPayloadS2CPacket(SAFE_ZONE_KICK, buf);
    }

    public static CustomPayloadS2CPacket maniacProximity(double distance) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeDouble(distance);
        return new CustomPayloadS2CPacket(MANIAC_PROXIMITY, buf);
    }
}
