package com.escapeprotocol.registry;

import com.escapeprotocol.EscapeProtocol;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModStatusEffects {
    private ModStatusEffects() {}

    /** Fear spiral: applied when sanity is critically low. */
    public static final StatusEffect PANIC = new PanicEffect(StatusEffectCategory.HARMFUL, 0x5B1A4E);
    /** Applied by "quiet steps" smoke or stealth items. */
    public static final StatusEffect QUIET_STEPS = new QuietStepsEffect(StatusEffectCategory.BENEFICIAL, 0x2E4A5B);

    public static class PanicEffect extends StatusEffect {
        protected PanicEffect(Category type, int color) { super(type, color); }
    }

    public static class QuietStepsEffect extends StatusEffect {
        protected QuietStepsEffect(Category type, int color) { super(type, color); }
    }

    public static void register() {
        Registry.register(Registries.STATUS_EFFECT,
                new Identifier(EscapeProtocol.MOD_ID, "panic"), PANIC);
        Registry.register(Registries.STATUS_EFFECT,
                new Identifier(EscapeProtocol.MOD_ID, "quiet_steps"), QUIET_STEPS);
    }
}
