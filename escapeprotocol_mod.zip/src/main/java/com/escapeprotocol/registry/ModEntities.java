package com.escapeprotocol.registry;

import com.escapeprotocol.EscapeProtocol;
import com.escapeprotocol.entity.DummySurvivorEntity;
import com.escapeprotocol.entity.ManiacEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    private ModEntities() {}

    public static final EntityType<ManiacEntity> MANIAC = EntityType.Builder
            .create(ManiacEntity::new, SpawnGroup.MISC)
            .dimensions(0.7f, 2.0f)
            .build();

    public static final EntityType<DummySurvivorEntity> DUMMY_SURVIVOR = EntityType.Builder
            .create(DummySurvivorEntity::new, SpawnGroup.MISC)
            .dimensions(0.6f, 1.8f)
            .build();

    public static void register() {
        Registry.register(Registries.ENTITY_TYPE,
                new Identifier(EscapeProtocol.MOD_ID, "maniac"), MANIAC);
        Registry.register(Registries.ENTITY_TYPE,
                new Identifier(EscapeProtocol.MOD_ID, "dummy_survivor"), DUMMY_SURVIVOR);

        FabricDefaultAttributeRegistry.register(MANIAC, ManiacEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DUMMY_SURVIVOR, DummySurvivorEntity.createAttributes());
    }
}
