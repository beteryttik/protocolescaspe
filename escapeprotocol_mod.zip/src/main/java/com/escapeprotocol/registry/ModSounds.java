package com.escapeprotocol.registry;

import com.escapeprotocol.EscapeProtocol;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/**
 * All custom sound events. Actual .ogg files live in
 * assets/escapeprotocol/sounds/ (procedural placeholders are shipped in this build).
 */
public final class ModSounds {
    private ModSounds() {}

    public static final SoundEvent AMBIENCE_HUM = register("ambience.hum");
    public static final SoundEvent CHASE_THEME = register("music.chase");
    public static final SoundEvent TENSION_THEME = register("music.tension");
    public static final SoundEvent HEARTBEAT = register("effect.heartbeat");
    public static final SoundEvent DOOR_CREAK = register("ambient.door_creak");
    public static final SoundEvent FAKE_FOOTSTEPS = register("ambient.fake_footsteps");
    public static final SoundEvent GENERATOR_HUM = register("block.generator_hum");
    public static final SoundEvent GENERATOR_FIXED = register("block.generator_fixed");
    public static final SoundEvent SAFE_ZONE_CLICK = register("block.safe_zone_click");
    public static final SoundEvent STING = register("effect.sting");
    public static final SoundEvent ELEVATOR_BELL = register("block.elevator_bell");
    public static final SoundEvent MANIAC_LAUGH = register("entity.maniac.laugh");
    public static final SoundEvent MANIAC_SCREAM = register("entity.maniac.scream");

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(EscapeProtocol.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // classloading triggers registration
    }
}
