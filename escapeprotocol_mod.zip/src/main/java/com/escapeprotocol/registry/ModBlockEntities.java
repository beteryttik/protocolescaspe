package com.escapeprotocol.registry;

import com.escapeprotocol.EscapeProtocol;
import com.escapeprotocol.block.GeneratorBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlockEntities {
    private ModBlockEntities() {}

    public static BlockEntityType<GeneratorBlockEntity> GENERATOR;

    public static void register() {
        GENERATOR = Registry.register(Registries.BLOCK_ENTITY_TYPE,
                new Identifier(EscapeProtocol.MOD_ID, "generator"),
                FabricBlockEntityTypeBuilder.create(GeneratorBlockEntity::new, ModBlocks.GENERATOR).build(null));
    }
}
