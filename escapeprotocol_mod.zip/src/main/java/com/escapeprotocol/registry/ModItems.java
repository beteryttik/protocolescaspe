package com.escapeprotocol.registry;

import com.escapeprotocol.EscapeProtocol;
import com.escapeprotocol.item.ChainItem;
import com.escapeprotocol.item.FlashlightItem;
import com.escapeprotocol.item.FuelCanItem;
import com.escapeprotocol.item.KeyItem;
import com.escapeprotocol.item.PuttyItem;
import com.escapeprotocol.item.SmokeGrenadeItem;
import com.escapeprotocol.item.TrapItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    private ModItems() {}

    public static final Item FLASHLIGHT = new FlashlightItem(new Item.Settings().maxCount(1));
    public static final Item KEY = new KeyItem(new Item.Settings());
    public static final Item FUEL_CAN = new FuelCanItem(new Item.Settings().maxCount(4));
    public static final Item SMOKE_GRENADE = new SmokeGrenadeItem(new Item.Settings().maxCount(2));
    public static final Item CHAIN = new ChainItem(new Item.Settings().maxCount(1));
    public static final Item BANDAGE = new Item(new Item.Settings().maxCount(4));
    public static final Item FLARE = new Item(new Item.Settings().maxCount(2));
    public static final Item PUTTY = new PuttyItem(new Item.Settings().maxCount(2));
    public static final Item TRAP = new TrapItem(new Item.Settings().maxCount(3));

    public static void register() {
        register("flashlight", FLASHLIGHT);
        register("key", KEY);
        register("fuel_can", FUEL_CAN);
        register("smoke_grenade", SMOKE_GRENADE);
        register("chain", CHAIN);
        register("bandage", BANDAGE);
        register("flare", FLARE);
        register("putty", PUTTY);
        register("trap", TRAP);
    }

    private static void register(String name, Item item) {
        Registry.register(Registries.ITEM, new Identifier(EscapeProtocol.MOD_ID, name), item);
    }
}
