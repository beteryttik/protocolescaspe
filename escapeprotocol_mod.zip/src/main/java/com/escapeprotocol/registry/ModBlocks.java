package com.escapeprotocol.registry;

import com.escapeprotocol.EscapeProtocol;
import com.escapeprotocol.block.ElevatorCallBlock;
import com.escapeprotocol.block.GeneratorBlock;
import com.escapeprotocol.block.MotionSensorBlock;
import com.escapeprotocol.block.SafeDoorBlock;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    private ModBlocks() {}

    public static final GeneratorBlock GENERATOR = new GeneratorBlock(GeneratorBlock.defaultSettings());
    public static final MotionSensorBlock MOTION_SENSOR = new MotionSensorBlock(MotionSensorBlock.defaultSettings());
    public static final SafeDoorBlock SAFE_DOOR = new SafeDoorBlock(SafeDoorBlock.defaultSettings());
    public static final ElevatorCallBlock ELEVATOR_CALL = new ElevatorCallBlock(ElevatorCallBlock.defaultSettings());

    public static void register() {
        register("generator", GENERATOR);
        register("motion_sensor", MOTION_SENSOR);
        register("safe_door", SAFE_DOOR);
        register("elevator_call", ELEVATOR_CALL);
    }

    private static void register(String name, Block block) {
        Registry.register(Registries.BLOCK, new Identifier(EscapeProtocol.MOD_ID, name), block);
    }
}
