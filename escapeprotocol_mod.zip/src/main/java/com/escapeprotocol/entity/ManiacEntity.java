package com.escapeprotocol.entity;

import com.escapeprotocol.ai.ManiacBrain;
import com.escapeprotocol.ai.ManiacState;
import com.escapeprotocol.ai.goals.AmbushGoal;
import com.escapeprotocol.ai.goals.HuntNoiseGoal;
import com.escapeprotocol.world.safezone.SafeZoneTracker;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

/**
 * The bot maniac used in solo / when no player wants the role.
 * Uses ManiacBrain for high-level decisions and vanilla-style goals for movement.
 */
public class ManiacEntity extends HostileEntity {
    private final ManiacBrain brain;

    public ManiacEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.brain = new ManiacBrain(this);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 8.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    public ManiacBrain getBrain() {
        return brain;
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        SafeZoneTracker zones = new SafeZoneTracker(); // TODO: inject shared tracker
        this.goalSelector.add(1, new HuntNoiseGoal(this, brain));
        this.goalSelector.add(2, new AmbushGoal(this, brain, zones));
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient && getWorld() instanceof ServerWorld serverWorld) {
            brain.tick(serverWorld, serverWorld.getServer().getTicks());
        }
    }

    @Override
    public boolean tryAttack(net.minecraft.entity.Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity) {
            // Stun window: the maniac pauses briefly after a successful hit.
            this.setStunned(40); // 2 seconds
        }
        return hit;
    }

    private void setStunned(int ticks) {
        // TODO: apply slowness + cannot-attack cooldown via attributes.
    }
}
