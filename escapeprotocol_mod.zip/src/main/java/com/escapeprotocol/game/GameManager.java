package com.escapeprotocol.game;

import com.escapeprotocol.config.EscapeProtocolConfig;
import com.escapeprotocol.config.ConfigManager;
import com.escapeprotocol.game.arena.ArenaManager;
import com.escapeprotocol.game.arena.SpawnService;
import com.escapeprotocol.game.lobby.LobbyManager;
import com.escapeprotocol.networking.Payloads;
import com.escapeprotocol.player.MatchPlayer;
import com.escapeprotocol.world.ArenaGenerator;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Single source of truth for match state. Everything asks this:
 * "is a match running?", "who is the maniac?", "is that player safe?".
 */
public final class GameManager {
    private static final GameManager INSTANCE = new GameManager();

    public static GameManager get() {
        return INSTANCE;
    }

    public enum Phase { LOBBY, SETUP, RUNNING, ENDED }

    private final Map<UUID, MatchPlayer> players = new Object2ObjectOpenHashMap<>();
    private final List<UUID> escaped = new ArrayList<>();
    private final List<UUID> dead = new ArrayList<>();

    private Phase phase = Phase.LOBBY;
    private UUID maniacId;
    private long matchStartTick;
    private long ticksElapsed;
    private boolean elevatorCalled;
    private long elevatorCallTick;
    private boolean rageMode;

    private GameManager() {}

    public Phase getPhase() {
        return phase;
    }

    public boolean isRunning() {
        return phase == Phase.RUNNING;
    }

    public boolean isManiac(ServerPlayerEntity player) {
        return player.getUuid().equals(maniacId);
    }

    public MatchPlayer data(ServerPlayerEntity player) {
        return players.computeIfAbsent(player.getUuid(), id -> new MatchPlayer(player));
    }

    public void startMatch(ServerWorld arena, ArenaManager.ArenaType type, List<ServerPlayerEntity> participants) {
        phase = Phase.SETUP;
        escaped.clear();
        dead.clear();
        players.clear();
        elevatorCalled = false;
        ticksElapsed = 0;

        // 1. Generate arena layout (rooms, keys, generators, elevator).
        ArenaGenerator generator = new ArenaGenerator(type);
        BlockPos center = new BlockPos(0, 80, 0);
        generator.generate(arena, center);

        // 2. Spawn maniac.
        ServerPlayerEntity maniac = SpawnService.pickManiac(participants);
        if (maniac == null) {
            maniac = participants.get(0); // fallback; nobody volunteered
        }
        maniacId = maniac.getUuid();

        // 3. Teleport everyone. Maniac to his cell, survivors to the lobby hall.
        SpawnService.teleportManiac(arena, maniac);
        for (ServerPlayerEntity p : participants) {
            if (p == maniac) continue;
            SpawnService.teleportSurvivor(arena, p);
            players.put(p.getUuid(), new MatchPlayer(p));
        }
        players.put(maniac.getUuid(), new MatchPlayer(maniac).asManiac());

        // 4. Maniac start lock: survivors get head start.
        maniac.addStatusEffect(new StatusEffectInstance(
                net.minecraft.entity.effect.StatusEffects.SLOWNESS,
                ConfigManager.get().maniacStartLockTicks(), 4, true, false));

        phase = Phase.RUNNING;
        matchStartTick = arena.getServer().getTicks();

        for (ServerPlayerEntity p : participants) {
            p.networkHandler.sendPacket(Payloads.matchStarted(type));
            p.sendMessage(Text.literal("\u00a76[EP]\u00a7r Match started. Good luck."), false);
        }
    }

    public void tick(net.minecraft.server.MinecraftServer server) {
        if (phase != Phase.RUNNING) return;
        ticksElapsed++;

        EscapeProtocolConfig cfg = ConfigManager.get();

        // Maniac unlock after start-lock period.
        if (ticksElapsed == cfg.maniacStartLockTicks()) {
            server.getPlayerManager().getPlayerList().stream()
                    .filter(p -> p.getUuid().equals(maniacId))
                    .findFirst()
                    .ifPresent(m -> m.sendMessage(Text.literal("\u00a7cThe maniac is loose."), false));
        }

        // Sanity ticking for survivors.
        for (MatchPlayer mp : players.values()) {
            mp.tickSanity(ticksElapsed);
        }

        // Final phase: rage mode.
        if (!rageMode && elevatorCalled && ticksElapsed - elevatorCallTick > cfg.elevatorCallTicks() / 2) {
            rageMode = true;
            broadcastToAll(server, Text.literal("\u00a7c[ELEVATOR] \u00a7rSomething speeds up in the dark..."));
        }

        // Elevator timer.
        if (elevatorCalled && ticksElapsed - elevatorCallTick >= cfg.elevatorCallTicks()) {
            endMatch(server, "SURVIVORS_ESCAPED");
        }

        // Time limit.
        if (ticksElapsed >= cfg.matchTimeLimitTicks()) {
            endMatch(server, "TIME_UP");
        }
    }

    public void markEscaped(ServerPlayerEntity player) {
        escaped.add(player.getUuid());
        checkEndConditions();
    }

    public void markDead(ServerPlayerEntity player) {
        dead.add(player.getUuid());
        checkEndConditions();
    }

    public void callElevator(long tick) {
        elevatorCalled = true;
        elevatorCallTick = tick;
    }

    public boolean isElevatorCalled() {
        return elevatorCalled;
    }

    private void checkEndConditions() {
        long totalSurvivors = players.values().stream().filter(mp -> !mp.isManiac()).count();
        if (escaped.size() + dead.size() >= totalSurvivors) {
            phase = Phase.ENDED;
        }
    }

    private void endMatch(net.minecraft.server.MinecraftServer server, String reason) {
        phase = Phase.ENDED;
        broadcastToAll(server, Text.literal("\u00a76[EP]\u00a7r Match over: " + reason));
        // TODO: award points, teleport to lobby world.
    }

    private void broadcastToAll(net.minecraft.server.MinecraftServer server, Text text) {
        for (var player : server.getPlayerManager().getPlayerList()) {
            player.sendMessage(text, false);
        }
    }
}
