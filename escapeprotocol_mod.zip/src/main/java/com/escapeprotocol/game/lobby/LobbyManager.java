package com.escapeprotocol.game.lobby;

import com.escapeprotocol.game.arena.ArenaManager;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Tracks who wants to play, their role preference, and the voted arena.
 * In the first iteration the lobby world is the server spawn area.
 */
public final class LobbyManager {
    private static final LobbyManager INSTANCE = new LobbyManager();

    public static LobbyManager get() {
        return INSTANCE;
    }

    public enum RolePreference { SURVIVOR, MANIAC, RANDOM }

    public record LobbyEntry(ServerPlayerEntity player, RolePreference preference) {}

    private final List<LobbyEntry> entries = new ArrayList<>();
    private final Set<UUID> ready = new HashSet<>();
    private ArenaManager.ArenaType votedArena = ArenaManager.ArenaType.HOTEL;

    private LobbyManager() {}

    public void join(ServerPlayerEntity player, RolePreference preference) {
        remove(player);
        entries.add(new LobbyEntry(player, preference));
        ready.add(player.getUuid());
        player.sendMessage(net.minecraft.text.Text.literal("\u00a7a[Lobby]\u00a7r Joined as " + preference), false);
    }

    public void leave(ServerPlayerEntity player) {
        remove(player);
    }

    private void remove(ServerPlayerEntity player) {
        entries.removeIf(e -> e.player().getUuid().equals(player.getUuid()));
        ready.remove(player.getUuid());
    }

    public List<LobbyEntry> getEntries() {
        return List.copyOf(entries);
    }

    public boolean hasMinimum(int min) {
        return entries.size() >= min;
    }

    public void voteArena(ArenaManager.ArenaType type) {
        this.votedArena = type;
    }

    public ArenaManager.ArenaType getVotedArena() {
        return votedArena;
    }

    public List<ServerPlayerEntity> participants() {
        return entries.stream().map(LobbyEntry::player).toList();
    }
}
