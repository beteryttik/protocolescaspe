package com.escapeprotocol.game.lobby;

import com.escapeprotocol.game.arena.ArenaManager;

import java.util.HashMap;
import java.util.Map;

/**
 * Simple first-past-the-post arena vote. TODO: weighted vote by party leader.
 */
public final class MapVoteService {
    private final Map<ArenaManager.ArenaType, Integer> votes = new HashMap<>();

    public void vote(ArenaManager.ArenaType type) {
        votes.merge(type, 1, Integer::sum);
    }

    public ArenaManager.ArenaType winner() {
        return votes.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(ArenaManager.ArenaType.HOTEL);
    }
}
