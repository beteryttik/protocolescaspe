package com.escapeprotocol.game.lobby;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.Random;

/**
 * Picks the maniac:
 * 1. If volunteers exist — pick one at random among them.
 * 2. If none — pick anyone at random. Nobody escapes the maniac role.
 */
public final class RolePicker {
    private RolePicker() {}

    public static ServerPlayerEntity pick(List<LobbyManager.LobbyEntry> entries, Random random) {
        List<ServerPlayerEntity> volunteers = entries.stream()
                .filter(e -> e.preference() == LobbyManager.RolePreference.MANIAC)
                .map(LobbyManager.LobbyEntry::player)
                .toList();

        List<ServerPlayerEntity> randoms = entries.stream()
                .filter(e -> e.preference() == LobbyManager.RolePreference.RANDOM)
                .map(LobbyManager.LobbyEntry::player)
                .toList();

        List<ServerPlayerEntity> pool = volunteers.isEmpty() ? randoms : volunteers;
        if (pool.isEmpty()) return null;
        return pool.get(random.nextInt(pool.size()));
    }
}
