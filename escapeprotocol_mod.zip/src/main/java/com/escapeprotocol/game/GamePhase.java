package com.escapeprotocol.game;

/**
 * Explicit phase enum mirroring GameManager.Phase for packet payloads.
 */
public enum GamePhase {
    LOBBY, SETUP, RUNNING, ENDED
}
