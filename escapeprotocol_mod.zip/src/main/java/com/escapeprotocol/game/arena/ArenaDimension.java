package com.escapeprotocol.game.arena;

import com.escapeprotocol.EscapeProtocol;
import net.minecraft.util.Identifier;
import net.minecraft.world.dimension.DimensionOptions;

/**
 * Handles creation/regeneration of the arena dimension.
 * First iteration: a single pre-registered dimension "ep_arena" is
 * wiped and rebuilt between matches. Later: per-match dynamic dimensions.
 */
public final class ArenaDimension {
    public static final Identifier ARENA_ID = new Identifier(EscapeProtocol.MOD_ID, "ep_arena");

    private ArenaDimension() {}

    // TODO: register DimensionOptions in a fabric data generator pack at build time.
    // For now, arenas use a flat overworld-like settings entry declared in the datapack.
    public static DimensionOptions options() {
        return null; // resolved from datapack in the first build
    }
}
