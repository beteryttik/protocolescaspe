package com.escapeprotocol.game.arena;

import java.util.List;

/**
 * Registry of arenas. Each arena is a distinct dimension that is
 * regenerated on every match start.
 */
public final class ArenaManager {
    private ArenaManager() {}

    public enum ArenaType {
        HOTEL("hotel", 4, 3, 1),
        HOSPITAL("hospital", 5, 4, 2),
        LAB("lab", 6, 5, 2),
        CLUB("club", 4, 2, 1);

        public final String id;
        public final int minKeys;
        public final int generators;
        public final int saveZones;

        ArenaType(String id, int minKeys, int generators, int saveZones) {
            this.id = id;
            this.minKeys = minKeys;
            this.generators = generators;
            this.saveZones = saveZones;
        }

        public static ArenaType byId(String id) {
            return List.of(values()).stream().filter(t -> t.id.equals(id)).findFirst().orElse(HOTEL);
        }
    }
}
