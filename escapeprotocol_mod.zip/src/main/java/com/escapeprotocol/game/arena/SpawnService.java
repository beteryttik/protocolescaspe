package com.escapeprotocol.game.arena;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Random;

/**
 * Handles match-start teleports. Maniac spawns deep in the basement,
 * survivors together in the main hall.
 */
public final class SpawnService {
    private SpawnService() {}

    public static ServerPlayerEntity pickManiac(List<ServerPlayerEntity> participants) {
        return RolePickerBridge.pick(participants);
    }

    public static void teleportManiac(ServerWorld arena, ServerPlayerEntity maniac) {
        BlockPos maniacSpawn = new BlockPos(4, 60, 4); // TODO: resolved from generator output
        maniac.teleport(arena, maniacSpawn.getX() + 0.5, maniacSpawn.getY(), maniacSpawn.getZ() + 0.5, 0, 0);
    }

    public static void teleportSurvivor(ServerWorld arena, ServerPlayerEntity survivor) {
        Random random = new Random();
        int x = 32 + random.nextInt(16) - 8;
        int z = 32 + random.nextInt(16) - 8;
        survivor.teleport(arena, x + 0.5, 64, z + 0.5, 0, 0);
    }

    private static final class RolePickerBridge {
        static ServerPlayerEntity pick(List<ServerPlayerEntity> participants) {
            return com.escapeprotocol.game.lobby.RolePicker.pick(
                    participants.stream().map(p -> new LobbyManager.LobbyEntry(p, LobbyManager.RolePreference.RANDOM)).toList(),
                    new Random());
        }
    }
}
