package com.escapeprotocol.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;

/**
 * Door of a save-zone. Survivors open it with a key-card; the maniac
 * can break it in ~8 seconds with a very loud NoiseEvent.
 */
public class SafeDoorBlock extends Block {
    protected SafeDoorBlock(Settings settings) {
        super(settings);
    }

    public static Settings defaultSettings() {
        return Settings.create().strength(4.0f, 12.0f);
    }
}
