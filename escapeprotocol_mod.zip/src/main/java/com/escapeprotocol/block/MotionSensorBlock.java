package com.escapeprotocol.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;

/**
 * Survivors can place these: they ping the maniac's silhouette through walls
 * for 3 seconds when he crosses the beam. The mimic does NOT trigger them
 * (a key tell in the Mimic mode).
 */
public class MotionSensorBlock extends Block {
    protected MotionSensorBlock(Settings settings) {
        super(settings);
    }

    public static Settings defaultSettings() {
        return Settings.create().strength(1.0f, 4.0f);
    }
}
