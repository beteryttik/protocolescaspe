package com.escapeprotocol.block;

import com.escapeprotocol.ai.NoiseEvent;
import com.escapeprotocol.ai.NoiseSystem;
import com.escapeprotocol.ai.NoiseType;
import com.escapeprotocol.game.GameManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * The final objective: calling the elevator. Needs all keys collected and
 * all generators fueled. Once called, a 60-second timer starts and the
 * maniac gets a RAGE speed buff.
 */
public class ElevatorCallBlock extends Block {
    protected ElevatorCallBlock(Settings settings) {
        super(settings);
    }

    public static Settings defaultSettings() {
        return Settings.create().strength(4.0f, 8.0f);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        if (world instanceof ServerWorld serverWorld) {
            if (!GameManager.get().isElevatorCalled()) {
                GameManager.get().callElevator(serverWorld.getServer().getTicks());
                NoiseSystem.publish(new NoiseEvent(pos, 48.0, NoiseType.ELEVATOR_CALL));
                serverWorld.getServer().getPlayerManager().getPlayerList()
                        .forEach(p -> p.sendMessage(net.minecraft.text.Text.literal("\u00a7a[ELEVATOR] \u00a7rCalled. Hold the line."), false));
            }
        }
        return ActionResult.CONSUME;
    }
}
