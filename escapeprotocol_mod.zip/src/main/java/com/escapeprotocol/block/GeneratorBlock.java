package com.escapeprotocol.block;

import com.escapeprotocol.block.GeneratorBlockEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ShapeContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * A generator that needs fuel and repair time. When running, it emits
 * periodic noise events that the maniac hears.
 */
public class GeneratorBlock extends BlockWithEntity {
    public static final BooleanProperty RUNNING = BooleanProperty.of("running");

    private static final VoxelShape SHAPE = Block.createCuboidShape(1, 0, 1, 15, 12, 15);

    protected GeneratorBlock(Settings settings) {
        super(settings);
        setDefaultState(getDefaultState().with(RUNNING, false));
    }

    public static Settings defaultSettings() {
        return Settings.create().strength(3.0f, 8.0f).nonOpaque();
    }

    @Override
    public BlockEntityCreate<GeneratorBlockEntity> newBlockEntity(BlockPos pos, BlockState state) {
        return null; // placeholder, replaced below by getBlockEntityType-based create
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(RUNNING);
    }
}
