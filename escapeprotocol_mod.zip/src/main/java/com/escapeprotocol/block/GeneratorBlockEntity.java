package com.escapeprotocol.block;

import com.escapeprotocol.ai.NoiseEvent;
import com.escapeprotocol.ai.NoiseSystem;
import com.escapeprotocol.ai.NoiseType;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class GeneratorBlockEntity extends BlockEntity {
    private static final String KEY_FUEL = "Fuel";
    private static final String KEY_PROGRESS = "Progress";

    private int fuelTicks;
    private int repairProgress;
    private int noiseCooldown;

    public GeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(com.escapeprotocol.registry.ModBlockEntities.GENERATOR, pos, state);
    }

    public boolean isRunning() {
        return fuelTicks > 0;
    }

    public boolean addFuel(int ticks) {
        fuelTicks += ticks;
        markDirty();
        return true;
    }

    public void tickServer(World world, BlockPos pos, BlockState state) {
        if (!isRunning()) return;
        if (--noiseCooldown <= 0) {
            noiseCooldown = 100; // every 5 seconds a running generator hums out loud
            NoiseSystem.publish(new NoiseEvent(pos, 20.0, NoiseType.GENERATOR_RUNNING));
        }
        fuelTicks--;
        markDirty();
    }

    @Override
    public void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putInt(KEY_FUEL, fuelTicks);
        nbt.putInt(KEY_PROGRESS, repairProgress);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        fuelTicks = nbt.getInt(KEY_FUEL);
        repairProgress = nbt.getInt(KEY_PROGRESS);
    }
}
