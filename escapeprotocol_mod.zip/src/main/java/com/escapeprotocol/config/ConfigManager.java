package com.escapeprotocol.config;

import com.escapeprotocol.EscapeProtocol;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Minimal JSON-free config: properties file in config/escapeprotocol.properties.
 * Missing keys fall back to defaults, unknown keys are ignored.
 */
public final class ConfigManager {
    private static EscapeProtocolConfig config = EscapeProtocolConfig.DEFAULT;

    private ConfigManager() {}

    public static EscapeProtocolConfig get() {
        return config;
    }

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("escapeprotocol.properties");
        Properties props = new Properties();
        if (Files.exists(path)) {
            try {
                props.load(Files.newInputStream(path));
            } catch (IOException e) {
                EscapeProtocol.LOGGER.warn("Failed to read config, using defaults", e);
            }
        }

        config = new EscapeProtocolConfig(
                intOr(props, "lobbyMinPlayers", 2),
                intOr(props, "maxSurvivors", 8),
                intOr(props, "maniacStartLockTicks", 1200),
                intOr(props, "safeZoneStayTicks", 1200),
                intOr(props, "safeZoneBreakTicks", 160),
                intOr(props, "matchTimeLimitTicks", 24000),
                intOr(props, "elevatorCallTicks", 1200),
                intOr(props, "rageSpeedPercentBonus", 30),
                doubleOr(props, "noiseRunRadius", 24.0),
                doubleOr(props, "noiseBlockBreakRadius", 16.0),
                doubleOr(props, "noiseWalkRadius", 8.0),
                doubleOr(props, "noiseSneakRadius", 4.0),
                doubleOr(props, "sanityDrainPerSecondDark", 0.35),
                doubleOr(props, "sanityDrainOnManiacSeen", 6.0),
                intOr(props, "maniacSightRange", 24),
                intOr(props, "maniacHearingRange", 32)
        );

        if (!Files.exists(path)) {
            save(path);
        }
    }

    private static int intOr(Properties p, String k, int def) {
        try { return Integer.parseInt(p.getProperty(k, String.valueOf(def))); }
        catch (NumberFormatException e) { return def; }
    }

    private static double doubleOr(Properties p, String k, double def) {
        try { return Double.parseDouble(p.getProperty(k, String.valueOf(def))); }
        catch (NumberFormatException e) { return def; }
    }

    private static void save(Path path) {
        try {
            Files.writeString(path, """
                    # Escape Protocol configuration
                    lobbyMinPlayers=2
                    maxSurvivors=8
                    maniacStartLockTicks=1200
                    safeZoneStayTicks=1200
                    safeZoneBreakTicks=160
                    matchTimeLimitTicks=24000
                    elevatorCallTicks=1200
                    rageSpeedPercentBonus=30
                    noiseRunRadius=24.0
                    noiseBlockBreakRadius=16.0
                    noiseWalkRadius=8.0
                    noiseSneakRadius=4.0
                    sanityDrainPerSecondDark=0.35
                    sanityDrainOnManiacSeen=6.0
                    maniacSightRange=24
                    maniacHearingRange=32
                    """);
        } catch (IOException e) {
            EscapeProtocol.LOGGER.warn("Failed to write default config", e);
        }
    }
}
