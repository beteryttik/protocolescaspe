package com.escapeprotocol.config;

/**
 * Immutable snapshot of tunable values. All balance knobs live here so
 * that tweaking does not require touching gameplay code.
 */
public record EscapeProtocolConfig(
        int lobbyMinPlayers,          // players required to start a match
        int maxSurvivors,             // survivors per match (maniac excluded)
        int maniacStartLockTicks,     // maniac is locked in his spawn for this long (60s = 1200)
        int safeZoneStayTicks,        // how long you may hide inside a save-zone (60s = 1200)
        int safeZoneBreakTicks,       // how long the maniac breaks the door (8s = 160)
        int matchTimeLimitTicks,      // hard time limit of a match (default 20 min)
        int elevatorCallTicks,        // elevator arrival timer (60s = 1200)
        int rageSpeedPercentBonus,    // final phase maniac speed bonus
        double noiseRunRadius,        // meters noise from running travels
        double noiseBlockBreakRadius,
        double noiseWalkRadius,
        double noiseSneakRadius,
        double sanityDrainPerSecondDark,
        double sanityDrainOnManiacSeen,
        int maniacSightRange,         // blocks, lit conditions
        int maniacHearingRange        // hard cap on noise he can hear
) {
    public static EscapeProtocolConfig DEFAULT = new EscapeProtocolConfig(
            2, 8, 1200, 1200, 160, 20 * 60 * 20, 1200, 30,
            24.0, 16.0, 8.0, 4.0,
            0.35, 6.0,
            24, 32
    );
}
