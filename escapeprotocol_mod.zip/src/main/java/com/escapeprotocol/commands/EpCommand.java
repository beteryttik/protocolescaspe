package com.escapeprotocol.commands;

import com.escapeprotocol.config.ConfigManager;
import com.escapeprotocol.game.GameManager;
import com.escapeprotocol.game.arena.ArenaManager;
import com.escapeprotocol.game.lobby.LobbyManager;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.literal;

public final class EpCommand {
    private EpCommand() {}

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("ep")
                .then(literal("join").executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    LobbyManager.get().join(player, LobbyManager.RolePreference.RANDOM);
                    ctx.getSource().sendFeedback(() -> Text.literal("\u00a7aJoined the lobby."), false);
                    return 1;
                }))
                .then(literal("role").then(literal("survivor").executes(ctx -> setRole(ctx.getSource(), LobbyManager.RolePreference.SURVIVOR))))
                .then(literal("role").then(literal("maniac").executes(ctx -> setRole(ctx.getSource(), LobbyManager.RolePreference.MANIAC))))
                .then(literal("role").then(literal("random").executes(ctx -> setRole(ctx.getSource(), LobbyManager.RolePreference.RANDOM))))
                .then(literal("start").executes(ctx -> {
                    if (!LobbyManager.get().hasMinimum(ConfigManager.get().lobbyMinPlayers())) {
                        ctx.getSource().sendError(Text.literal("Not enough players in lobby."));
                        return 0;
                    }
                    ctx.getSource().sendFeedback(() -> Text.literal("\u00a7aMatch starting..."), false);
                    // TODO: resolve arena world, call GameManager.startMatch
                    return 1;
                }))
                .then(literal("status").executes(ctx -> {
                    ctx.getSource().sendFeedback(() -> Text.literal("Phase: " + GameManager.get().getPhase()), false);
                    return 1;
                })));
    }

    private static int setRole(ServerCommandSource source, LobbyManager.RolePreference role) {
        ServerPlayerEntity player = source.getPlayer();
        LobbyManager.get().join(player, role);
        source.sendFeedback(() -> Text.literal("\u00a7aRole preference set to " + role), false);
        return 1;
    }
}
