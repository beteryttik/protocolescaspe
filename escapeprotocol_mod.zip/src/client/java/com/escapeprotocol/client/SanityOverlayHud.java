package com.escapeprotocol.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * Draws a dark vignette that intensifies as sanity drops, plus the
 * sanity bar itself. At sanity < 25 shows false silhouettes (TODO).
 */
public final class SanityOverlayHud {
    private SanityOverlayHud() {}

    public static void init() {
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> render(drawContext, tickDelta));
    }

    private static void render(DrawContext ctx, float tickDelta) {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        // TODO: read sanity from the synced payload; draw gradient + bar.
    }
}
