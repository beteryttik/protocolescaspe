package com.escapeprotocol.client;

/**
 * Screen shake during chase: applies a small randomized camera offset
 * while the chase packet is active.
 */
public final class ChaseShakeEffect {
    private static int shakeTicksRemaining;

    private ChaseShakeEffect() {}

    public static void init() {
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                Payloads.CHASE_STATE, (client, handler, buf, responseSender) -> {
                    boolean chasing = buf.readBoolean();
                    if (chasing) shakeTicksRemaining = 200; else shakeTicksRemaining = 0;
                });
    }

    public static void tick() {
        if (shakeTicksRemaining > 0) shakeTicksRemaining--;
    }
}
