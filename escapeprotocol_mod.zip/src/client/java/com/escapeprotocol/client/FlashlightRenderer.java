package com.escapeprotocol.client;

/**
 * Renders the flashlight cone from the player's hand and draws the beam
 * spot on surfaces. Must be visible to other players (server-aware).
 */
public final class FlashlightRenderer {
    private FlashlightRenderer() {}

    public static void init() {
        // TODO: WorldRenderEvents.END hook for the beam cone + spotlight shader.
    }
}
