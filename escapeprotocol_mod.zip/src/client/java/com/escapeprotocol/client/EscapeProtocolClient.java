package com.escapeprotocol.client;

import net.fabricmc.api.ClientModInitializer;

public class EscapeProtocolClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AudioDirector.init();
        SanityOverlayHud.init();
        ChaseShakeEffect.init();
        FlashlightRenderer.init();
        // TODO: entity renderers for ManiacEntity / DummySurvivorEntity.
    }
}
