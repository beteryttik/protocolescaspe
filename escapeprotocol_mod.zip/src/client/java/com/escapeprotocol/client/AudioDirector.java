package com.escapeprotocol.client;

import com.escapeprotocol.networking.Payloads;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundCategory;

/**
 * Adaptive soundtrack. Receives proximity/chase packets from the server
 * and cross-fades between the calm ambience, the tension theme and the chase theme.
 *
 * Calm:    always audible baseline.
 * Tension: maniac closer than 30 blocks.
 * Chase:   maniac has line of sight.
 */
public final class AudioDirector {
    public enum Mood { CALM, TENSION, CHASE }

    private static Mood mood = Mood.CALM;
    private static float tensionLevel = 0f; // 0..1

    private AudioDirector() {}

    public static void init() {
        // Register network receivers that feed mood changes.
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                Payloads.MANIAC_PROXIMITY, (client, handler, buf, responseSender) -> {
                    double dist = buf.readDouble();
                    client.execute(() -> setProximity(dist));
                });
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                Payloads.CHASE_STATE, (client, handler, buf, responseSender) -> {
                    boolean chasing = buf.readBoolean();
                    client.execute(() -> mood = chasing ? Mood.CHASE : Mood.TENSION);
                });
    }

    public static void setProximity(double distance) {
        if (distance > 30) tensionLevel = 0;
        else tensionLevel = 1f - (float) (distance / 30.0);
        if (mood == Mood.CHASE && distance > 32) mood = Mood.TENSION;
    }

    public static Mood getMood() {
        return mood;
    }

    public static float getTensionLevel() {
        return tensionLevel;
    }

    /** Called each client tick to drive heartbeat layers. */
    public static void tick() {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (tensionLevel > 0.7f) {
            // Heartbeat pulses sync with sanity; simplified: play on a cooldown.
            // TODO: dedicated SoundInstance with looping control.
        }
    }
}
