# Escape Protocol — Design Document

Asymmetric multiplayer horror mod for Fabric 1.20.1.

## Vision
1 maniac vs 1..8 survivors in a procedurally generated safehouse.
Survivors collect keys, fuel generators, and call the elevator.
The maniac hunts noise, sets traps, and can mimic survivors until
the first strike (Mimic mode).

## Core loop
Lobby -> vote arena -> teleport -> 60s head start -> match -> elevator -> rewards -> lobby

## Arenas
- HOTEL (v1): 1 floor, 4 keys, 3 generators, 1 save-zone
- HOSPITAL: 2 floors, 5 keys, 4 generators, 2 save-zones
- LAB: 2 floors, 6 keys, 5 generators, 2 save-zones
- CLUB: 1 floor dense, 4 keys, 2 generators, 1 save-zone

## Save-zones
- Maniac cannot damage players inside
- 60s occupancy timer, then the door clicks open (loud)
- Maniac can break the door in 8s — loud NoiseEvent to everyone
- Contains a bandage + small chance of fuel/flares
- Maniac can camp the door: survivors must weigh safety vs time

## The Mimic mode
Before the first strike the maniac looks like one of the survivors.
Tells:
- Motion sensors do not ping for the mimic
- His flashlight never runs out of charge
- The sound of his footsteps is subtly different (1-2 dB quieter)

## Maniac kit
- Trap (3 per match): immobilizes a survivor
- Dash: short sprint burst with cooldown
- Hearing pulse: silhouettes of noise sources through walls for 3s
- Rage (endgame): +30% speed during elevator countdown

## Survivor kit
- Flashlight with charge; beam visible from afar
- 2 pocket slots (handcrafted small inventory, not full inventory)
- Smoke grenade, chain (stun), bandage, flare, door putty
- Sanity: drains in darkness; panic effects under threshold

## Elevator finale
Called from the ElevatorCallBlock once keys + generators are done.
60s arrival timer; the maniac is pushed away from the elevator and
gains RAGE speed. Survivors must hold the line.

## Scoring
- Survive: +100
- Revive ally: +25
- Fix generator: +15
- Find key: +10
- Maniac win: scales with survivors caught
