# Roadmap

## v0.1 (MVP)
- [x] GameManager FSM (LOBBY/SETUP/RUNNING/ENDED)
- [x] RoomGraph + ArenaGenerator skeleton
- [x] NoiseSystem pub/sub
- [x] ManiacBrain FSM (PATROL/INVESTIGATE/CHASE/SEARCH/AMBUSH/RAGE)
- [x] SafeZoneData + SafeZoneTracker
- [x] Basic items (flashlight, key, fuel, smoke, chain, putty, trap)
- [ ] Place NBT templates for 5-7 room variants per arena
- [ ] Wire StealthHelper into movement events (mixins)
- [ ] AudioDirector loop switch + actual ogg files

## v0.2
- [ ] Multiplayer role sync + lobby UI
- [ ] Player-controlled maniac with own HUD
- [ ] Elevator finale scene
- [ ] Revive mechanic
- [ ] Scoring + cosmetic unlocks

## v0.3
- [ ] Mimic mode
- [ ] Sanity hallucinations (fake sounds/silhouettes)
- [ ] Arena variety: HOSPITAL, LAB, CLUB
- [ ] Weekly modifiers

## v1.0
- [ ] CurseForge / Modrinth release
- [ ] Server config sync
- [ ] Localization: RU/EN
