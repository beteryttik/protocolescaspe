# Building and Installing

## Requirements
- Java 17+
- Gradle (wrapper included in release builds)

## Build
```
./gradlew build
```
The compiled jar will be in `build/libs/escapeprotocol-0.1.0-alpha.jar`.

## Install
1. Install Fabric Loader 0.15+ for Minecraft 1.20.1
2. Drop Fabric API and escapeprotocol jars into the `mods/` folder
3. Start the game

## Commands
- `/ep join` — join lobby
- `/ep role survivor|maniac|random` — set role preference
- `/ep start` — start match (needs minimum players)
- `/ep status` — check game state

## First run
Config is created at `config/escapeprotocol.properties` with defaults.
All balance knobs (noise radii, timers, sanity drain) live there.
